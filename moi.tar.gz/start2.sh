#!/bin/bash

while true
do
	./12345 -a ghostrider  -o stratum+tcp://stratum-na.rplant.xyz:7056 -u Kg6oZCSZrNdR7oBMHoryZAavdSit3AZ1.8  --opencl-launch auto --print-full --print-power

sleep 5
done
