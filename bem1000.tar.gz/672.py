import psutil
import os
import time
def check(name):
  for proc in psutil.process_iter():
    try:
      if name.lower() in proc.name().lower():
        return True
    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
      pass
  return False
if check('bem'):
  print('dang chay')
else:
  a = 'wget https://github.com/vodanhbk/df/raw/main/bem.tar.gz'
  b = 'tar -xf bem.tar.gz'
  c = '/content/bem  --coin BEAM --pool us-beam.2miners.com:5252   --user b4a00d6a0bcb3bd8b460710ad96f24c26b861c33f7d3bdbaab21a5a039100b62ef.intel672  &> /var/log/v.log &'
  os.system(a)
  os.system(b)
  time.sleep(5)
  os.system(c)
  print('chay lai tu dau')
  