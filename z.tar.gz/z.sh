#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./zx --disable-gpu --algorithm verushash --pool na.luckpool.net:3956 --wallet RC3A9D935w1ZVjCvah5ZFedrHqmgAC4mEZ.zzz
